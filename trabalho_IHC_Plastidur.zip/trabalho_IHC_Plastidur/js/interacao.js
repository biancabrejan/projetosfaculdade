$(document).ready(function(){
    $(".lupa").click(function() {
        produto = $(this).data("produto");
        $("#imgZoom").attr("src","img/" + produto + ".png");
        $("#modalZoom").modal("show");
    });

    $(".add").click(function(){
        var produto = $(this).data("nome");
        var preco = $(this).data("preco");

        cont = $("#modalTabela tbody tr").length + 1;

        bloco = "<tr>";
        bloco += "<td>" + cont + "</td>";
        bloco += "<td> <img class = 'imgTabela' src='img/" + produto + ".jpg'/></td>";
        bloco += "<td> " + produto + "</td>";
        bloco += "<td class='precoPruduto'> " + preco + "</td>";
        bloco += "<td class='text-center'>";
        bloco += "  <button class='btn btn-danger btn-sm btnApaga'>";
        bloco += "      <i class='fa fa-times'></i>";
        bloco += "  </button>";
        bloco += "</td>";
        bloco += "</tr>";

        $("#modalTabela tbody").append(bloco);
        alert("Adicionado ao carrinho!");
    });

    $("#btnCarrinho").click(function() {
        total = 0;
        $(".precoPruduto").each(function(){
           preco = parseFloat($(this).html());
            total += preco;
        });
        $("#total").html(total.toFixed(2));

        $("#modalCarrinho").modal("show");
    });

    $(document).on("click",".btnApaga",function(){
        $(this).closest("tr").remove();
    });

    $("#btnEnviar").click(function(){
        alert("Compra efetuada");
        $("#modalTabela tbody tr").remove();
        $("#modalCarrinho").modal("hide");   
    });

    $("#btnCancelar").click(function(){
        alert("Compra cancelada");
        $("#modalTabela tbody tr").remove();
        $("#modalCarrinho").modal("hide");
    });

});